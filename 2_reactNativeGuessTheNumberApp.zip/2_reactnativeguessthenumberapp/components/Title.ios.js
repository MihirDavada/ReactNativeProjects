import { Text, StyleSheet , Platform } from 'react-native';

const Title = (props) => {
  return <Text style={styles.title}> {props.children} </Text>;
};

export default Title;

const styles = StyleSheet.create({
  title: {
    fontFamily : 'open-sans-bold',
    fontSize: 24,
    color: 'white',
    textAlign: 'center',
    // borderWidth: Platform.OS == "android" ? 2 : 0 ,
    borderWidth: 0,    
    borderColor: 'white',
    padding: 12
  }
});


// Platform.OS == "ios"
// Platform.OS == "android"
// Platform.OS == "macos"
// Platform.OS == "windows"
// Platform.OS == "web"