import { View, Text, Pressable, StyleSheet , Platform } from 'react-native';
import Colors from '../Constants/Colors'

const PrimaryButton = (props) => {
  const onPressHandler = () => {
    props.onPress()
  };

  return (
    <View style={styles.buttonOuterContainer}>
      <Pressable
        style={({ pressed }) =>
          pressed
            ? [styles.buttonInnerContainer, styles.pressed]
            : styles.buttonInnerContainer
        }
        onPress={onPressHandler}
        android_ripple={{ color: Colors.primary600 }}>
        <Text style={[styles.buttonText, Platform.OS === 'web' && styles.webButtonText]}>{props.children}</Text>
      </Pressable>
    </View>
  );
};
// styles.buttonInnerContainer

export default PrimaryButton;

const styles = StyleSheet.create({
  buttonOuterContainer: {
    borderRadius: 28,
    margin: 4,
    overflow: 'hidden',
  },
  buttonInnerContainer: {
    backgroundColor: Colors.primary500,
    paddingVertical: 8,
    paddingHorizontal: 16,
    elevation: 2,
    whiteSpace: 'nowrap'
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
    
  },
  pressed: {
    opacity: 0.75,
  },
  webButtonText : {
    whiteSpace: 'nowrap',
    paddingRight: 8
  }
});
