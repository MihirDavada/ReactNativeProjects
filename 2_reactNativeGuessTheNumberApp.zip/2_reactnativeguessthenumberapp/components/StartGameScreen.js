import React from 'react';
import {
  TextInput,
  View,
  StyleSheet,
  Alert,
  useWindowDimensions,
  KeyboardAvoidingView,
  ScrollView,
  Platform
} from 'react-native';
import PrimaryButton from './PrimaryButton';
import { useState } from 'react';
import Colors from '../Constants/Colors';
import Title from './Title';
import Card from './Card';
import InstructionText from './InstructionText';

const StartGameScreen = (props) => {
  const [enteredNumber, setEnteredNumber] = useState('');

  const { height, width } = useWindowDimensions();
  // console.log(height , width)
  // Horizontal - ( h = 423 , w = 818)
  // Vertical - ( h = 818, w = 423 )

  const enteredNumberHandler = (enteredText) => {
    setEnteredNumber(enteredText);
  };

  const onPressResetHandler = () => {
    setEnteredNumber('');
    console.log('onPressResetHandler');
  };

  const onPressConfirmHandler = () => {
    const num = parseInt(enteredNumber);

    if (isNaN(num) || num <= 0 || num > 99) {
      // Show Alert
      Alert.alert('Invalid Number', 'Number Has To Be Number Between 1 to 99', [
        {
          text: 'Okay',
          style: 'destructive',
          onPress: onPressResetHandler,
        },
      ]);

      return;
    }

    props.onPick(enteredNumber);
  };

  let marginTopDistance = height > 700 ? 200 : 70;

  return (
    <ScrollView style = {styles.screen}>
      <KeyboardAvoidingView style={styles.scren} behavior="position">
        <View style={[styles.rootContainer, { marginTop: marginTopDistance }]}>
          <Title> Guess The Number</Title>
          <Card>
            <InstructionText> Enter The Number </InstructionText>
            <TextInput
              style={styles.textInputContainer}
              maxLength={2}
              keyboardType="number-pad"
              value={enteredNumber}
              onChangeText={enteredNumberHandler}
            />
            <View style={styles.primaryButtonOuterContainer}>
              <View style={styles.primaryButtonInnerContainer}>
                <PrimaryButton onPress={onPressResetHandler}>
                  Reset
                </PrimaryButton>
              </View>

              <View style={styles.primaryButtonInnerContainer}>
                <PrimaryButton onPress={onPressConfirmHandler}>
                  Confirm
                </PrimaryButton>
              </View>
            </View>
          </Card>
        </View>
      </KeyboardAvoidingView>
    </ScrollView>
  );
};

export default StartGameScreen;

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  rootContainer: {
    flex: 1,
    alignItems: 'center',
  },
  textInputContainer: {
    height: 50,
    width: 50,
    textAlign: 'center',
    fontSize: 32,
    borderBottomWidth: 2,
    borderBottomColor: Colors.accent500,
    color: Colors.accent500,
    marginVertical: 8,
    fontWeight: 'bold',
    alignItems: 'center',
  },
  primaryButtonOuterContainer: {
    flexDirection: 'row',
  },
  primaryButtonInnerContainer: {
    flex: 1,
  },
});
