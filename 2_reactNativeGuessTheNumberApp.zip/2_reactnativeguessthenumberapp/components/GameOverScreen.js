import {
  View,
  Text,
  StyleSheet,
  Image,
  useWindowDimensions,
  ScrollView,
  Platform
} from 'react-native';
import Title from './Title';
import Colors from '../Constants/Colors';
import PrimaryButton from './PrimaryButton';

const GameOverScreen = (props) => {
  const { height, width } = useWindowDimensions();

  imageWidth = width > 500 ? 150 : 300;
  imageHeight = width > 500 ? 150 : 300;
  imageBorderRadius = width > 500 ? 75 : 150;

  let imageStyle = {
    width: imageWidth,
    height: imageHeight,
    borderRadius: imageBorderRadius,
  };

  return (
    <ScrollView style={styles.screen}>
      <View style={styles.rootContainer}>
        <Title> Game Is Over </Title>
        <View style={[styles.imageContainer, imageStyle]}>
          <Image
            style={styles.image}
            source={require('../Assets/success.png')}
          />
        </View>
        <View>
          <Text style={styles.summaryText}>
            Your Phone Needed
            <Text style={styles.highlight}> {props.roundNumber} </Text> Rounds
            To Guess The Number
            <Text style={styles.highlight}> {props.userNumber} </Text>
          </Text>
          <PrimaryButton onPress={props.onStartGame}>
            Start The New Game
          </PrimaryButton>
        </View>
      </View>
    </ScrollView>
  );
};

export default GameOverScreen;

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  rootContainer: {
    flex: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop : Platform.select({android:60})
  },
  imageContainer: {
    borderWidth: 3,
    borderColor: Colors.primary800,
    overflow: 'hidden',
    margin: 36,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  summaryText: {
    fontFamily: 'open-sans',
    fontSize: 24,
    textAlign: 'center',
    marginBottom: 24,
  },
  highlight: {
    fontFamily: 'open-sans-bold',
    color: Colors.primary500,
  },
});
