import { View, Text, StyleSheet , Dimensions,useWindowDimensions } from 'react-native';
import Colors from '../Constants/Colors';

const NumberContainer = (props) => {
  const { height, width } = useWindowDimensions();

    let landWidth = width > 500 ? "90%" :"88%";
    let paddingDistance = width > 500 ? 10 : 24;
    let marginDistance = width > 500 ? 20 : 24;
    let font =  width > 500 ? 24 : 36;


  return (
    <View style={[styles.viewContainer , { width : landWidth }, { padding : paddingDistance } , {margin : marginDistance} ]}>
      <Text style={[styles.textContainer, { fontSize : font }]}> {props.children} </Text>
    </View>
  );
};

export default NumberContainer;



const styles = StyleSheet.create({
  viewContainer: {
    borderWidth: 4,
    borderColor: Colors.accent500,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textContainer: {    
    fontFamily : "open-sans-bold",
    color: Colors.accent500,
  },
});
