import { View, Text, StyleSheet , Dimensions, useWindowDimensions } from 'react-native';
import Colors from '../Constants/Colors'

const Card = (props) => {
  const { height, width } = useWindowDimensions();
  let landWidth = width > 500 ? "90%" :"88%";
  let marginTopDistance = width > 500 ? 10 : 36
  return <View style={[styles.viewContainer , { width : landWidth } , { marginTop : marginTopDistance }]}>{props.children}</View>;
};

export default Card;


const styles = StyleSheet.create({
  viewContainer: {
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 24,
    padding: 16,
    backgroundColor: Colors.primary800,
    borderRadius: 8,
    elevation: 8,
    shadowColor: 'black',
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 6,
    shadowOpacity: 0.25,
  },
});
