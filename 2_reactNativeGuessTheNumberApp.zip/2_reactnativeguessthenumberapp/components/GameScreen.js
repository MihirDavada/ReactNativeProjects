import {
  View,
  Text,
  StyleSheet,
  Alert,
  FlatList,
  useWindowDimensions,
} from 'react-native';
import Title from './Title';
import NumberContainer from './NumberContainer';
import PrimaryButton from './PrimaryButton';
import { useState, useEffect, useMemo } from 'react';
import Card from './Card';
import InstructionText from './InstructionText';
import Ionicons from '@expo/vector-icons/Ionicons';
import GuessLogItem from './GuessLogItem';

const generateRandomNumberBetween = (min, max, exclude) => {
  const randomNumber = Math.floor(Math.random() * (max - min)) + min;

  if (randomNumber == exclude) {
    return generateRandomNumberBetween(min, max, exclude);
  } else {
    return randomNumber;
  }
};

minBound = 1;
maxBound = 100;

const GameScreen = ({ userNumber, gameOverHandler }) => {
  initialGuess = generateRandomNumberBetween(1, 100, userNumber);
  const [currentGuess, setCurrentGuess] = useState(initialGuess);
  const [guessRounds, setGuessRounds] = useState([]);
  const { height, width } = useWindowDimensions();

  useEffect(() => {
    if (currentGuess == userNumber) {
      gameOverHandler(guessRounds.length);
      minBound = 1;
      maxBound = 100;
    }
  }, [currentGuess, userNumber, gameOverHandler, guessRounds]);

  const nextGuessHandler = (direction) => {
    if (
      (direction === 'Lower' && currentGuess < userNumber) ||
      (direction === 'Higher' && currentGuess > userNumber)
    ) {
      Alert.alert('Do Not Lie', 'You Know That Is Wrong ', [
        { text: 'Sorry', style: 'cancel' },
      ]);
      return;
    }

    if (direction === 'Lower') {
      maxBound = currentGuess;
    } else {
      minBound = currentGuess + 1;
    }
    console.log(minBound, maxBound);

    const newRandomNumber = generateRandomNumberBetween(
      minBound,
      maxBound,
      currentGuess
    );
    setCurrentGuess(newRandomNumber);

    setGuessRounds((preState) => {
      return [newRandomNumber, ...preState];
    });
  };

  const guessRoundsListLength = guessRounds.length;

  let content = (
    <>
      <Title> Oponent Guess </Title>
      <NumberContainer> {currentGuess}</NumberContainer>
      <Card>
        <InstructionText style={styles.instructionText}>
          Higher or Lower
        </InstructionText>
        <View style={styles.primaryButtonOuterContainer}>
          <View style={styles.primaryButtonInnerContainer}>
            <PrimaryButton onPress={nextGuessHandler.bind(this, 'Lower')}>
              <Ionicons name="md-remove" size={24} color="white">
                {' '}
              </Ionicons>
            </PrimaryButton>
          </View>
          <View style={styles.primaryButtonInnerContainer}>
            <PrimaryButton onPress={nextGuessHandler.bind(this, 'Higher')}>
              <Ionicons name="md-add" size={24} color="white">
                {' '}
              </Ionicons>
            </PrimaryButton>
          </View>
        </View>
      </Card>
      <View style={styles.listContainer}>
        <FlatList
          data={guessRounds}
          renderItem={(itemObject) => {
            return (
              <GuessLogItem
                roundNumber={guessRoundsListLength - itemObject.index}
                guess={itemObject.item}
              />
            );
          }}
        />
      </View>
    </>
  );

  if (width > 500) {
    content = (
      <>
        <Title> Oponent Guess Width </Title>
        <View style = {styles.flexContainer}>
          <View style = {styles.flexChildOne}>
            <NumberContainer> {currentGuess}</NumberContainer>
            <Card>
              <InstructionText style={styles.instructionText}>
                Higher or Lower
              </InstructionText>
              <View style={styles.primaryButtonOuterContainer}>
                <View style={styles.primaryButtonInnerContainer}>
                  <PrimaryButton onPress={nextGuessHandler.bind(this, 'Lower')}>
                    <Ionicons name="md-remove" size={24} color="white">
                      {' '}
                    </Ionicons>
                  </PrimaryButton>
                </View>
                <View style={styles.primaryButtonInnerContainer}>
                  <PrimaryButton
                    onPress={nextGuessHandler.bind(this, 'Higher')}>
                    <Ionicons name="md-add" size={24} color="white">
                      {' '}
                    </Ionicons>
                  </PrimaryButton>
                </View>
              </View>
            </Card>
          </View>

          <View style = {styles.flexChildTwo}>
            <View style={styles.listContainer}>
              <FlatList
                data={guessRounds}
                renderItem={(itemObject) => {
                  return (
                    <GuessLogItem
                      roundNumber={guessRoundsListLength - itemObject.index}
                      guess={itemObject.item}
                    />
                  );
                }}
              />
            </View>
          </View>
        </View>
      </>
    );
  }

  return <View style={styles.screen}>{content}</View>;
};

// {guessRounds.map((item, index) => {
//   return <Text key={index}> {item} </Text>;
// })}

export default GameScreen;

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    padding: 24,
    marginTop: 50,
  },
  primaryButtonOuterContainer: {
    flexDirection: 'row',
  },
  primaryButtonInnerContainer: {
    flex: 1,
  },
  instructionText: {
    marginBottom: 12,
  },
  listContainer: {
    flex: 1,
    padding: 24,
  },
  flexContainer:{
    flex :1,
    flexDirection : 'row'
  },
  flexChildOne : {
    flex : 0.5

  },
  flexChildTwo : {
    flex : 0.5
  }
});
