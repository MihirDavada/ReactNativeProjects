import { ImageBackground, StyleSheet, SafeAreaView } from 'react-native';
import StartGameScreen from './components/StartGameScreen.js';
import { LinearGradient } from 'expo-linear-gradient';
import { useState } from 'react';
import GameScreen from './components/GameScreen.js';
import Colors from './Constants/Colors';
import GameOverScreen from './components/GameOverScreen';
import { useFonts } from 'expo-font';
import AppLoading from 'expo-app-loading';
import { StatusBar } from 'expo-status-bar';

const App = () => {
  const [pickedNumber, setPickedNumber] = useState();
  const [gameIsOver, setGameIsOver] = useState(true);
  const [numberOfRounds, setNumberOfRounds] = useState(0);

  const pickedNumberHandler = (userPickedNumber) => {
    setPickedNumber(userPickedNumber);
    setGameIsOver(false);
  };

  const gameOverHandler = (roundNumber) => {
    setGameIsOver(true);
    setNumberOfRounds(roundNumber);
  };

  const onStartGameHandler = () => {
    setPickedNumber(null);
    setNumberOfRounds(0);
  };

  let screen = <StartGameScreen onPick={pickedNumberHandler} />;

  if (pickedNumber) {
    screen = (
      <GameScreen userNumber={pickedNumber} gameOverHandler={gameOverHandler} />
    );
  }

  if (gameIsOver && pickedNumber) {
    screen = (
      <GameOverScreen
        roundNumber={numberOfRounds}
        userNumber={pickedNumber}
        onStartGame={onStartGameHandler}
      />
    );
  }

  const [isFontLoaded] = useFonts({
    'open-sans': require('./Fonts/OpenSans-Regular.ttf'),
    'open-sans-bold': require('./Fonts/OpenSans-Bold.ttf'),
  });

  if (!isFontLoaded) {
    return <AppLoading />;
  }

  return (
    <>
      <StatusBar style="light" />
      <LinearGradient
        colors={[Colors.primary700, Colors.accent500]}
        style={styles.rootContainer}>
        <ImageBackground
          source={require('./Assets/background.jpg')}
          resizeMode="cover"
          style={styles.rootContainer}
          imageStyle={styles.backgroundImage}>
          <SafeAreaView style={styles.rootContainer}>{screen}</SafeAreaView>
        </ImageBackground>
      </LinearGradient>
    </>
  );
};

export default App;

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
  },
  backgroundImage: {
    opacity: 0.15,
  },
});
