import { createContext } from 'react'

// expenseData = { description: 'A Pair Of Trousers', amount: 89.29, date: new Date('2022-01-05')}

const ExpenseContext = createContext({
  expenses: [],
  addExpense: ({ description, amount, date }) => {},
  setExpenses : (expenses) =>{},
  deleteExpense: (id) => {},
  updateExpense: (id, { description, amount, date }) => {},
});


export default ExpenseContext;