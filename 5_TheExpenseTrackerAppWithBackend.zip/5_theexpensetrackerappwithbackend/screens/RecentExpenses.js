import { StyleSheet } from 'react-native';
import Expenses from '../components/ShowExpenses/Expenses';
import { useContext, useState } from 'react';
import ExpenseContext from '../Store/ContextAPI/ExpenseContext';
import { GetDateMinusDays } from '../components/GetFormattedDate';
import { useEffect } from 'react';
import { fetchExpensesHTTP } from '../SendHTTPRequest/HTTP';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorHTTP from '../components/ErrorHTTP';

const RecentExpenses = () => {
  const expensesCtx = useContext(ExpenseContext);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function getExpenses() {
      setIsLoading(true);

      try {
        const expenses = await fetchExpensesHTTP();
        expensesCtx.setExpenses(expenses);
      } catch (error) {
        setError('Could Not Fetch Expenses');
      }
      setIsLoading(false);
    }
    getExpenses();
  }, []);

  const onConfirmHandler = () =>{
    setError(null)
  }

  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (error && !isLoading) {
    return <ErrorHTTP msg = {error} onConfirm = {onConfirmHandler} />;
  }

  // console.log(fetchedExpenses)

  const recentExpenses = expensesCtx.expenses.filter((expense) => {
    const today = new Date();
    const date7DaysAgo = GetDateMinusDays(today, 7);
    const expenseDate = new Date(expense.date);
    return expenseDate > date7DaysAgo;
  });

  return (
    <Expenses
      expenses={recentExpenses}
      periodTime="Past 7 Days"
      fallBackText="No Expenses Registered For The Last 7 Days"
    />
  );
};

export default RecentExpenses;

const styles = StyleSheet.create({});
// {id:"e1",description:"A Pair Of Shoes",amount:59.99,date:"2021-12-19T00:00:00.000Z"}
