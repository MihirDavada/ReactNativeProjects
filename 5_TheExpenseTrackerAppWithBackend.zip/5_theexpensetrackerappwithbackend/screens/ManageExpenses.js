import { View, StyleSheet } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useLayoutEffect } from 'react';
import IconButton from '../components/IconButton';
import { GlobalStyles } from '../constants/GlobalStyles';
import { useContext, useState } from 'react';
import ExpenseContext from '../Store/ContextAPI/ExpenseContext';
import ExpenseForm from '../components/ManageExpenses/ExpenseForm';
import {
  addExpenseHTTP,
  updateExpenseHTTP,
  deleteExpenseHTTP,
} from '../SendHTTPRequest/HTTP';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorHTTP from '../components/ErrorHTTP';

const ManageExpenses = () => {
  const expensesCtx = useContext(ExpenseContext);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState();

  const route = useRoute();
  const navigation = useNavigation();

  const expenseId = route.params?.expenseId;
  // console.log(expenseId);

  const selectedExpense = expensesCtx.expenses.find(
    (expense) => expense.id === expenseId
  );
  const isEditing = !!expenseId;

  useLayoutEffect(() => {
    navigation.setOptions({
      title: isEditing ? 'Edit Expenses' : 'Add Expenses',
    });
  }, [navigation, isEditing]);

  const onPressCancelButtonHandler = () => {
    navigation.goBack();
  };

  const onPressDeleteButtonHandler = async () => {
    setIsSubmitting(true);
    try {
      await deleteExpenseHTTP(expenseId);
      expensesCtx.deleteExpense(expenseId);
      navigation.goBack();
    } catch (error) {
      setError('Could Not Delete Expenses');
      setIsSubmitting(false);
    }
  };

  const onPressEditAddButtonHandler = async (expenseData) => {
    setIsSubmitting(true);
    try {
      if (isEditing) {
        expensesCtx.updateExpense(expenseId, expenseData);
        await updateExpenseHTTP(expenseId, expenseData);
      } else {
        const id = await addExpenseHTTP(expenseData);
        expensesCtx.addExpense({ ...expenseData, id: id });
      }
      navigation.goBack();
    } catch (error) {
      setError("Could Not Save Data...Try Again");
      setIsSubmitting(false);
    }
  };

  const onConfirmHandler = () => {
    setError(null);
  };

  if (isSubmitting) {
    return <LoadingSpinner />;
  }

  if (error && !isSubmitting) {
    return <ErrorHTTP msg={error} onConfirm={onConfirmHandler} />;
  }

  return (
    <View style={styles.mainContainer}>
      <ExpenseForm
        isEditing={isEditing}
        onPressSubmitHandler={onPressEditAddButtonHandler}
        onPressCancelButtonHandler={onPressCancelButtonHandler}
        defaultValue={selectedExpense}
      />

      {isEditing && (
        <View style={styles.deleteContainer}>
          <IconButton
            icon="trash"
            size={36}
            color={GlobalStyles.colors.error500}
            onPress={onPressDeleteButtonHandler}
          />
        </View>
      )}
    </View>
  );
};

export default ManageExpenses;

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    padding: 24,
    backgroundColor: GlobalStyles.colors.primary800,
  },
  deleteContainer: {
    marginTop: 16,
    paddingTop: 8,
    borderTopWidth: 2,
    borderTopColor: GlobalStyles.colors.primary200,
    alignItems: 'center',
  },
});

// navigation.goBack() - It Is Used To Go Back To The Previous Screen( From Which You Come To The Current Screen)
