import { Text, View, StyleSheet } from 'react-native';
import Expenses from '../components/ShowExpenses/Expenses'
import {useContext} from 'react';
import ExpenseContext from '../Store/ContextAPI/ExpenseContext'

const AllExpenses = () =>{
  const expensesCtx = useContext(ExpenseContext)
  return <Expenses expenses = {expensesCtx.expenses} periodTime = "Total" fallBackText = " No Registered Expenses Found " />
}

export default AllExpenses

const styles = StyleSheet.create({
  
})
