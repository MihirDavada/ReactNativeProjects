import { Text, View, StyleSheet, Alert } from 'react-native';
import Input from './Input';
import { useState } from 'react';
import CustomButton from '../CustomButton';
import { useNavigation } from '@react-navigation/native';
import { GetFormattedDate } from '../GetFormattedDate';
import { GlobalStyles } from '../../constants/GlobalStyles';

const ExpenseForm = (props) => {
  const navigation = useNavigation();

  const [inputValue, setInputValue] = useState({
    amount: {
      value: props.defaultValue ? props.defaultValue.amount.toString() : '',
      isValid: true,
    },
    date: {
      value: props.defaultValue
        ? GetFormattedDate(props.defaultValue.date)
        : '',
      isValid: true,
    },
    description: {
      value: props.defaultValue ? props.defaultValue.description : '',
      isValid: true,
    },
  });

  const inputChangeHandler = (inputIdentifier, enteredValue) => {
    setInputValue((preState) => {
      return {
        ...preState,
        [inputIdentifier]: { value: enteredValue, isValid: true },
      };
    });
  };

  const submitHandler = () => {
    const expenseData = {
      amount: +inputValue.amount.value,
      date: new Date(inputValue.date.value),
      description: inputValue.description.value,
    };

    const amountIsValid = !isNaN(expenseData.amount) && expenseData.amount > 0;
    const dateIsValid = expenseData.date.toString() !== 'Invalid Date';
    const descriptionIsValid = expenseData.description.trim().length > 0;

    if (amountIsValid && dateIsValid && descriptionIsValid) {
      props.onPressSubmitHandler(expenseData);
    } else {
      setInputValue((preState) => {
        return {
          amount: {
            value: preState.amount.value,
            isValid: amountIsValid,
          },
          date: {
            value: preState.date.value,
            isValid: dateIsValid,
          },
          description: {
            value: preState.description.value,
            isValid: descriptionIsValid,
          },
        };
      });
      return;
    }
  };
    
  const formIsValid =  inputValue.amount.isValid && inputValue.date.isValid && inputValue.description.isValid;

  return (
    <View style={styles.formStyle}>
      <Text style={styles.title}> Add Your Expense </Text>
      <View style={styles.amountDateContainer}>
        <Input
          label="Amount"
          inValid = {!inputValue.amount.isValid}
          textInputConfig={{
            keyboardType: 'decimal-pad',
            onChangeText: inputChangeHandler.bind(this, 'amount'),
            value: inputValue.amount.value,
          }}
        />
        <Input
          label="Date"
          inValid = {!inputValue.date.isValid}
          textInputConfig={{
            placeholder: 'YYYY-MM-DD',
            maxLength: 10,
            onChangeText: inputChangeHandler.bind(this, 'date'),
            value: inputValue.date.value,
          }}
        />
      </View>
      <View>
        <Input
          label="Description"
          inValid = {!inputValue.description.isValid}
          textInputConfig={{
            multiline: true,
            onChangeText: inputChangeHandler.bind(this, 'description'),
            value: inputValue.description.value,
          }}
        />
      </View>

      {!formIsValid && <Text style = {styles.errorText}> Invalid Input Values - Please Check Your Entered Data </Text> }

      <View style={styles.buttonContainer}>
        <CustomButton
          style={styles.button}
          mode="alt"
          onPress={props.onPressCancelButtonHandler}>
          Cancel
        </CustomButton>

        <CustomButton style={styles.button} onPress={submitHandler}>
          {props.isEditing ? 'Edit' : 'Add'}
        </CustomButton>
      </View>
    </View>
  );
};

export default ExpenseForm;

const styles = StyleSheet.create({
  amountDateContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  formStyle: {
    marginTop: 40,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginVertical: 24,
    textAlign: 'center',
  },
  button: {
    minWidth: 120,
    marginHorizontal: 8,
  },
  buttonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  errorText: {
    textAlign: 'center',
    color: GlobalStyles.colors.error500,
    margin: 8,
  },
});
