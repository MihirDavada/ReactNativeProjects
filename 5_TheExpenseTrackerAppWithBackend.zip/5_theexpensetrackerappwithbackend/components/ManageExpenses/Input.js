import { Text, View, StyleSheet, TextInput } from 'react-native';
import { GlobalStyles } from '../../constants/GlobalStyles';

const Input = (props) => {
  return (
    <View
      style={[
        styles.inputContainer,
        props.label == 'Amount' && styles.amountDate,
        props.label == 'Date' && styles.amountDate,
      ]}>
      <Text style={[styles.label, props.inValid && styles.invalidLabel]}>
        {props.label}
      </Text>
      <TextInput
        style={[
          styles.input,
          props.label == 'Description' && styles.inputMultiline,
          props.inValid && styles.invalidInput,
        ]}
        {...props.textInputConfig}
      />
    </View>
  );
};

export default Input;

const styles = StyleSheet.create({
  inputContainer: {
    marginHorizontal: 4,
    marginVertical: 8,
  },
  label: {
    fontSize: 12,
    marginBottom: 4,
    color: GlobalStyles.colors.primary100,
  },
  input: {
    backgroundColor: GlobalStyles.colors.primary100,
    color: GlobalStyles.colors.primary700,
    padding: 6,
    borderRadius: 6,
    fontSize: 18,
  },
  inputMultiline: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  amountDate: {
    flex: 1,
  },
  invalidLabel: {
    color: GlobalStyles.colors.error500,
  },
  invalidInput: {
    backgroundColor: GlobalStyles.colors.error50,
  },
});
