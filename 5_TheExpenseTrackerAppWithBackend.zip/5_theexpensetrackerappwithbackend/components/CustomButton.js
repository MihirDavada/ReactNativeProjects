import { Text, View, StyleSheet, Pressable } from 'react-native';
import { GlobalStyles} from '../constants/GlobalStyles'

const CustomButton = (props) => {
  return (
    <View style = {props.style}>
      <Pressable onPress = {props.onPress} style = {({pressed})=>{ return pressed && styles.pressed}} >
        <View style = {[styles.buttonStyle , props.mode === 'alt' && styles.alternateButtonStyle]}>
          <Text style = {[styles.buttonTextStyle , props.mode === 'alt' && styles.alternateButtonTextStyle ]} > <Text>{ props.children }</Text></Text>
        </View>
      </Pressable>
    </View>
  );
};

export default CustomButton;

const styles = StyleSheet.create({
  buttonStyle : {
    borderRadius : 4 , 
    padding : 8,
    backgroundColor : GlobalStyles.colors.primary500
  },
  alternateButtonStyle : {
    backgroundColor : "transparent"
  },
  buttonTextStyle : {
    color : 'white',
    textAlign : 'center'
  },
  alternateButtonTextStyle : {
    color : GlobalStyles.colors.primary500
  },
  pressed:{
    opacity : 0.75,
    backgroundColor : GlobalStyles.colors.primary100,
    borderRadius : 4
  }

})