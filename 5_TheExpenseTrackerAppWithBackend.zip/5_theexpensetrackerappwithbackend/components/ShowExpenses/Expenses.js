import { Text, View, StyleSheet } from 'react-native';
import ExpensesSummary from './ExpensesSummary';
import ExpensesList from './ExpensesList';
import { GlobalStyles } from '../../constants/GlobalStyles';
import DUMMY_EXPENSES from '../../DUMMY_DATA/DummyData';

const Expenses = (props) => {
  let content = <Text style = {styles.fallBackTextStyle}> { props.fallBackText } </Text>
  
  if( props.expenses.length > 0 ){
    content = <ExpensesList expensesObject={props.expenses} />
  }

  return (
    <View style={styles.viewContainer}>
      <ExpensesSummary
        expensesObject={props.expenses}
        periodTime={props.periodTime}
      />

      {content}
      
    </View>
  );
};

export default Expenses;

const styles = StyleSheet.create({
  viewContainer: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 0,
    backgroundColor: GlobalStyles.colors.primary700,
    flex: 1,
  },
  fallBackTextStyle : {
    color : "white",
    fontSize : 16,
    textAlign : "center",
    marginTop : 32,
  }
});
