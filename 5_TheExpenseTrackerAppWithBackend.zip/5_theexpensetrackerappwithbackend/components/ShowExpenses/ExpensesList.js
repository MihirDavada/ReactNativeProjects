import { Text, View, StyleSheet, FlatList } from 'react-native';
import ExpensesItem from './ExpenseItem'

const ExpensesList = (props) => {
  const renderItemHandler = (expenseObject) => {
    return <ExpensesItem expense = {expenseObject.item} />;
  };
  return (
    <FlatList data={props.expensesObject} renderItem={renderItemHandler} />
  );
};

export default ExpensesList;

const styles = StyleSheet.create({
});
