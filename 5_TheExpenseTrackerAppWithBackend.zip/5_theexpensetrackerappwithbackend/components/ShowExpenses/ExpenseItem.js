import { Text, View, StyleSheet, Pressable } from 'react-native';
import { GlobalStyles } from '../../constants/GlobalStyles';
import { useNavigation } from '@react-navigation/native';
import { GetFormattedDate } from '../GetFormattedDate';

const ExpenseItem = (props) => {
  const navigation = useNavigation();


  const onPressExpensesHandler = () => {
    navigation.navigate("ManageExpenses", {
      expenseId  : props.expense.id,
    })
  };

  return (
    <Pressable
      onPress={onPressExpensesHandler}
      style={({ pressed }) => {
        return pressed && styles.pressed;
      }}>
      <View style={styles.expenseItemContainer}>
        <View>
          <Text style={[styles.textColor, styles.description]}>
            {props.expense.description.length > 20 ? props.expense.description.slice(0,18) + "..." : props.expense.description }
          </Text>
          <Text style={styles.textColor}>
            {GetFormattedDate(props.expense.date)}
          </Text>
        </View>
        <View style={styles.amountContainer}>
          <Text style={styles.amount}> {props.expense.amount.toFixed(2)} </Text>
        </View>
      </View>
    </Pressable>
  );
};

export default ExpenseItem;

const styles = StyleSheet.create({
  pressed: {
    opacity: 0.5,
  },
  expenseItemContainer: {
    padding: 12,
    marginVertical: 8,
    backgroundColor: GlobalStyles.colors.primary500,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderRadius: 6,
    elevation: 3,
    shadowColor: GlobalStyles.colors.gray500,
    shadowRadius: 4,
    shadowOpacity: 0.4,
    shadowOffset: { width: 1, height: 1 },
  },
  textColor: {
    color: GlobalStyles.colors.primary50,
  },
  description: {
    fontSize: 16,
    marginBottom: 4,
    fontWeight: 'bold',
  },
  amountContainer: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 4,
    minWidth: 80,
  },
  amount: {
    color: GlobalStyles.colors.primary500,
    fontWeight: 'bold',
  },
});
