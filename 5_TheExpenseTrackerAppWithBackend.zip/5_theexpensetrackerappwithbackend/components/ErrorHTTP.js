import { Text, View, StyleSheet} from 'react-native';
import {GlobalStyles} from '../constants/GlobalStyles'
import CustomButton from './CustomButton'

const ErrorHTTP = (props) => {
  return (
    <View style = {styles.container}>
      <Text style = {[styles.text , styles.title]}> An Error Occurred </Text>
      <Text style = {styles.text}> {props.msg} </Text>
      <CustomButton onPress = {props.onConfirm} > Okay </CustomButton>
    </View>
  );
};

export default ErrorHTTP;

const styles = StyleSheet.create({
  container : {
    flex : 1,
    alignItems : "center",
    justifyContent : "center",
    padding : 24, 
    backgroundColor : GlobalStyles.colors.primary700
  },
  text : {
    textAlign : 'center',
    marginBottom : 8,
    color : 'white',
  },
  title : {
    fontSize:20,
    fontWeight : 'bold'
  },
});

