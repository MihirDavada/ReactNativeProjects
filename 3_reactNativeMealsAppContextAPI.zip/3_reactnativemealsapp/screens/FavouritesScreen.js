import { Text, View, StyleSheet } from 'react-native';
import { useContext } from 'react';
import FavouriteContext from '../Store/Context/FavouriteContext';
import MealList from '../components/MealList';
import { MEALS } from '../data/dummy-data';

const FavouritesScreen = () => {
  const favouriteMealsContext = useContext(FavouriteContext);

  const displayMeals = MEALS.filter((meal) =>
    favouriteMealsContext.ids.includes(meal.id)
  );

  if (displayMeals.length == 0) {
    return (
      <View style = {[styles.viewContainer , {justifyContent : "center" , alignItems:"center"}]}>
        <Text style = {styles.text}> You Have No Favourite Meals Yet.</Text>
      </View>
    );
  }

  return (
    <View style={styles.viewContainer}>
      <MealList displayMeals={displayMeals} />
    </View>
  );
};

export default FavouritesScreen;

const styles = StyleSheet.create({
  viewContainer: {
    flex: 1,
    backgroundColor: '#3f2f25',
  },
  text : {
    fontSize : 18,
    fontWeight : "bold",
    color : "white"

  }
});
