import { configureStore } from '@reduxjs/toolkit'

const Store = configureStore({
  reducer: {},
})

export default Store

