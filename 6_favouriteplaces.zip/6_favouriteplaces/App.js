import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Colors } from './Constants/colors';
import AllPlaces from './screens/AllPlaces';
import AddPlace from './screens/AddPlace';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Map from './screens/Map';
import { useEffect, useState } from 'react';
import init from './Util/database';
import AppLoading from 'expo-app-loading';

const Tab = createBottomTabNavigator();

export default function App() {
  const [dbInitialized, setDbInitialized] = useState();

  useEffect(() => {
    init()
      .then(() => {
        setDbInitialized(true);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  if (!dbInitialized) {
    return <AppLoading />;
  }

  return (
    <>
      <StatusBar style="dark" />
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            tabBarIcon: ({ focused, color, size }) => {
              let iconName;

              if (route.name === 'All Places') {
                iconName = focused ? 'ios-list' : 'ios-list-outline';
              } else if (route.name === 'Add Place') {
                iconName = focused ? 'ios-add' : 'ios-add-outline';
              }

              return <Ionicons name={iconName} size={size} color={color} />;
            },
            tabBarActiveTintColor: 'black',
            tabBarInactiveTintColor: 'gray',
            tabBarStyle: { backgroundColor: Colors.primary500 },
            tabBarLabelStyle: { color: 'black' },
            headerStyle: { backgroundColor: Colors.primary500 },
          })}>
          <Tab.Screen
            name="All Places"
            component={AllPlaces}
            options={{ tabBarLabel: 'All Favourite Places' }}
          />
          <Tab.Screen
            name="Add Place"
            component={AddPlace}
            options={{ title: 'Add New Place' }}
          />
          <Tab.Screen
            name="Map"
            component={Map}
            options={{ tabBarButton: () => null }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </>
  );
}
