class Place {
  constructor(title, image, lat , long) {
    this.title = title;
    this.image = image;
    this.lat = lat; // { lat: 0.141241, lng: 127.121 }
    this.long = long; // { lat: 0.141241, lng: 127.121 }
  }
}