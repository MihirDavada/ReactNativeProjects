import MapView, { Marker } from 'react-native-maps';
import { StyleSheet, Alert  } from 'react-native';
import { useState, useLayoutEffect , useCallback } from 'react';
import { useNavigation } from '@react-navigation/native';
import IconButton from '../components/UI/IconButton';
const Map = () => {
  const [selectedLocation, setSelectedLocation] = useState();

  const navigation = useNavigation();

  const region = {
    latitude: 23.102821,
    longitude: 72.5062384,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  };

  const selectLocationHandler = (event) => {
    const lat = event.nativeEvent.coordinate.latitude;
    const long = event.nativeEvent.coordinate.longitude;

    setSelectedLocation({ lat: lat, long: long });
  };

  const savePickedLocationHandler = useCallback( () => {
    if (!selectedLocation) {
      Alert.alert(
        'No Location Picked',
        'You Have To Pic Location By Tapping On The Map First'
      );
      return;
    }
    navigation.navigate('Add Place', {
      pickedLat: selectedLocation.lat,
      pickedLong: selectedLocation.long,
    });
  } , [navigation , selectedLocation])

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: ({ tintColor }) => {
        return (
          <IconButton
            icon="save"
            size={24}
            color={tintColor}
            onPress={savePickedLocationHandler}
          />
        );
      },
    });
  }, [navigation , savePickedLocationHandler]);

  return (
    <MapView
      style={styles.map}
      initialRegion={region}
      onPress={selectLocationHandler}>
      {selectedLocation && (
        <Marker
          title="Picked Location"
          coordinate={{
            latitude: selectedLocation.lat,
            longitude: selectedLocation.long,
          }}
        />
      )}
    </MapView>
  );
};

export default Map;

const styles = StyleSheet.create({
  map: {
    flex: 1,
  },
});
