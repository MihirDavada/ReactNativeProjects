import PlacesList from '../components/Places/PlacesList';
import { View } from 'react-native';
import { Colors } from '../Constants/colors';
import {
  useNavigation,
  useRoute,
  useIsFocused,
} from '@react-navigation/native';
import { useEffect , useState } from 'react';
import { fetchPlaces } from '../Util/database'

function AllPlaces() {

  const route = useRoute();

  const [loadedPlaces , setLoadedPlaces] = useState([])
  const isFocused = useIsFocused();


  useEffect(() => {

    const loadPlacesFromDB = async() => {
       const fetchedPlaces = await fetchPlaces()

       setLoadedPlaces(fetchedPlaces)
    }

    if (isFocused) {

      loadPlacesFromDB()
    }
  }, [isFocused]);

  return (
    <View style={{ flex: 1, backgroundColor: Colors.gray700 }}>
      <PlacesList places = {loadedPlaces} />
    </View>
  );
}

export default AllPlaces;
