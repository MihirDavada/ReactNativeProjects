import PlaceForm from '../components/Places/PlaceForm';
import { View } from 'react-native';
import { Colors } from '../Constants/colors';
import { useNavigation } from '@react-navigation/native';
import { insertPlace } from '../Util/database';

function AddPlace() {
  const navigation = useNavigation();

  const createPlaceHandler = async (placeData) => {    
    await insertPlace(placeData)

    navigation.navigate('All Places');
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.gray700 }}>
      <PlaceForm onCreatePlace={createPlaceHandler} />
    </View>
  );
}

export default AddPlace;
