import { Alert, View, StyleSheet, Text } from 'react-native';
import OutlinedButton from '../UI/OutlinedButton';
import { Colors } from '../../Constants/colors';
import { useState, useEffect } from 'react';
import {
  getCurrentPositionAsync,
  useForegroundPermissions,
  PermissionStatus,
} from 'expo-location';

import {
  useNavigation,
  useRoute,
  useIsFocused,
} from '@react-navigation/native';

const LocationPicker = (props) => {
  const [locationPermissionInformation, requestPermission] =
    useForegroundPermissions();

  const isFocused = useIsFocused();

  const [pickedLocation, setPickedLocation] = useState();

  const navigation = useNavigation();

  const route = useRoute();

  useEffect(() => {
    if (isFocused && route.params) {
      
      const mapPickedLocation = route.params
        ? { lat: route.params.pickedLat, long: route.params.pickedLong }
        : null;
        
      setPickedLocation(mapPickedLocation);
    }

  }, [route, isFocused]);

  useEffect(()=>{
    props.onPickLocation(pickedLocation)

  } , [pickedLocation , props])

  async function verifyPermissions() {
    if (
      locationPermissionInformation.status === PermissionStatus.UNDETERMINED
    ) {
      const permissionResponse = await requestPermission();
      return permissionResponse.granted;
    }

    if (locationPermissionInformation.status === PermissionStatus.DENIED) {
      Alert.alert(
        'Insufficient Permissions',
        'You Need To Grant Location Permissions To Use This App.'
      );
      return false;
    }
    return true;
  }

  const getLocationHandler = async () => {
    const hasPermissions = await verifyPermissions();

    if (!hasPermissions) {
      return;
    }

    let location = await getCurrentPositionAsync({});

    setPickedLocation({
      lat: location.coords.latitude,
      long: location.coords.longitude,
    });
  };

  const picOnMapHandler = () => {
    navigation.navigate('Map');
  };

  let locationPreview = <Text> No Location Picked Yet </Text>;

  if (pickedLocation) {
    locationPreview = (
      <View>
        <Text>Open The Google Map And Search Below Text</Text>
        <Text>
          {pickedLocation.lat} ,{pickedLocation.long}
        </Text>
      </View>
    );
  }

  return (
    <View>
      <View style={styles.mapPreviewStyle}>
        <Text> {locationPreview}</Text>
      </View>
      <View style={styles.actions}>
        <OutlinedButton icon="location" onPress={getLocationHandler}>
          Locate The User
        </OutlinedButton>
        <OutlinedButton icon="map" onPress={picOnMapHandler}>
          Pick On Map
        </OutlinedButton>
      </View>
    </View>
  );
};

export default LocationPicker;

const styles = StyleSheet.create({
  mapPreviewStyle: {
    width: '100%',
    height: 200,
    marginVertical: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 4,
    backgroundColor: Colors.primary100,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
});
