import { View, Button, Text, StyleSheet , Alert ,Image } from 'react-native';
import { launchCameraAsync , useCameraPermissions  , PermissionStatus} from 'expo-image-picker';
import { useState } from 'react'
import {Colors} from '../../Constants/colors'
import OutlinedButton from '../UI/OutlinedButton'

const ImagePicker = (props) => {

  const [cameraPermissionInformation , requestPermission ] = useCameraPermissions()

  const [pickedImage , setPickedImage] = useState()

  async function verifyPermissions() {
    if( cameraPermissionInformation.status === PermissionStatus.UNDETERMINED ){
      const permissionResponse = await requestPermission()
      return permissionResponse.granted
    }

   if(cameraPermissionInformation.status === PermissionStatus.DENIED){
     Alert.alert("Insufficient Permissions" , "You Need To Grant Camera Permissions To Use This App.")
     return false
   } 
   return true;
  }

  const takeImageHandler = async () => {

    const hasPermissions = await verifyPermissions()

    if(!hasPermissions){
      return;
    }
    let image = await launchCameraAsync({
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.5,
    });

    setPickedImage(image.uri)
    props.onTakeImage(image.uri)
  };

  let imagePreview = <Text> No Image Taken Yet. </Text>

  if(pickedImage){
    imagePreview = <Image style = {styles.image} source = {{uri : pickedImage}} />
  }


  return (
    <View>
      <View style = {styles.imagePreviewStyle} >{imagePreview}</View>
      <OutlinedButton icon = "camera"  onPress={takeImageHandler}> Take Image </OutlinedButton>
    </View>
  );
};

export default ImagePicker;

const styles = StyleSheet.create({
  imagePreviewStyle :{
    width : "100%",
    height : 200,
    marginVertical : 8,
    justifyContent : "center",
    alignItems : 'center',
    borderRadius : 4 , 
    backgroundColor : Colors.primary100
  },
  image : {
    width : "100%",
    height : "100%"
  }

});
