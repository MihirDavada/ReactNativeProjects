import { Text, View, ScrollView, TextInput, StyleSheet } from 'react-native';
import { useState, useCallback } from 'react';
import { Colors } from '../../Constants/colors';
import ImagePicker from './ImagePicker';
import LocationPicker from './LocationPicker';
import Button from '../UI/Button';
import { Place } from '../../models/place';

function PlaceForm(props) {
  const [enteredTitle, setEnteredTitle] = useState();
  const [takeImage, setTakeImage] = useState();
  const [pickLocation, setPickLocation] = useState();

  const enteredTitleHandler = (enteredText) => {
    setEnteredTitle(enteredText);
  };

  const takeImageHandler = (imageURI) => {
    setTakeImage(imageURI);
  };

  const pickLocationHandler = useCallback((location) => {
    setPickLocation(location);
  }, []);

  const savePlaceHandler = () => {
    const placeData = {
      title: enteredTitle,
      image: takeImage,
      lat: pickLocation.lat,
      long: pickLocation.long,
    };

    props.onCreatePlace(placeData);
  };

  return (
    <ScrollView style={styles.form}>
      <View>
        <Text style={styles.label}> Title </Text>

        <TextInput style={styles.input} onChangeText={enteredTitleHandler} />
      </View>
      <ImagePicker onTakeImage={takeImageHandler} />
      <LocationPicker onPickLocation={pickLocationHandler} />
      <Button onPress={savePlaceHandler}> Add Place </Button>
    </ScrollView>
  );
}

export default PlaceForm;

const styles = StyleSheet.create({
  form: {
    flex: 1,
    padding: 24,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 4,
    color: Colors.primary500,
  },
  input: {
    marginVertical: 8,
    paddingHorizontal: 4,
    paddingVertical: 8,
    fontSize: 16,
    borderBottomColor: Colors.primary700,
    borderBottomWidth: 2,
    backgroundColor: Colors.primary100,
  },
});
