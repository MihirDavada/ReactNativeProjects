import { View, StyleSheet, FlatList, Button } from "react-native";
import { useState } from "react";
import ListItem from "./components/ListItem";
import ListInput from "./components/ListInput";
import { StatusBar } from "expo-status-bar";

const App = () => {
  const [listOfGoals, setListOfGoals] = useState([]);
  const [modalIsVisible, setModalIsVisible] = useState(false);

  const onPressDeleteHandler = (deleteItem) => {
    setListOfGoals((preState) => {
      return preState.filter((item) => {
        return item !== deleteItem;
      });
    });
  };

  const onPressButtonHandler = (enteredInput) => {
    setListOfGoals((preState) => [...preState, enteredInput]);
    setModalIsVisible(false);
  };

  const onPressStartModalHandler = () => {
    setModalIsVisible(true);
  };

  const onPressCloseModalHandler = () => {
    setModalIsVisible(false);
  };

  return (
    <>
      <StatusBar style="light" />
       <View style={styles.appContainer}>
        <Button
          title="Add New Goal"
          color="#5e0acc"
          onPress={onPressStartModalHandler}
        />
        {modalIsVisible && (
          <ListInput
            visible={modalIsVisible}
            onPressButtonHandler={onPressButtonHandler}
            onPressCloseModalHandler={onPressCloseModalHandler}
          />
        )}

        <View style={styles.goalsContainer}>
          <FlatList
            data={listOfGoals}
            renderItem={(itemObject) => {
              return (
                <ListItem
                  item={itemObject.item}
                  index={itemObject.index}
                  onPressDeleteHandler={onPressDeleteHandler}
                />
              );
            }}
          />
        </View>
      </View>
    </>
  );
};

export default App;

const styles = StyleSheet.create({
  appContainer: {
    paddingTop: 50,
    paddingHorizontal: 16,
    flex: 1,
    backgroundColor: "#1e085a",
  },
  goalsContainer: {
    flex: 3,
  },
});
