import {
  View,
  StyleSheet,
  Button,
  TextInput,
  Modal,
  Image,
} from 'react-native';
import { useState } from 'react';

const ListInput = (props) => {
  const [enteredInput, setEnteredInput] = useState('');

  const onChangeInputHandler = (enteredText) => {
    setEnteredInput(enteredText);
  };

  const onPressButton = () => {
    props.onPressButtonHandler(enteredInput);
    setEnteredInput('');
  };

  return (
    <Modal visible={props.visible} animationType="slide">
      <View style={styles.inputContainer}>
        <Image
          style={styles.image}
          source={require('../assets/images/goal.png')}
        />
        <TextInput
          value={enteredInput}
          onChangeText={onChangeInputHandler}
          style={styles.textInput}
          placeholder="Your Course Goal!"
        />
        <View style={styles.buttonContainer}>
          <View style={styles.button}>
            <Button
              onPress={onPressButton}
              title="Add Goal"
              color="#b180f0"></Button>
          </View>

          <View style={styles.button}>
            <Button
              title="Cancel"
              onPress={props.onPressCloseModalHandler}
              color="#f31280"></Button>
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default ListInput;

const styles = StyleSheet.create({
  inputContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#311b66',
  },
  textInput: {
    borderColor: '#e4d0ff',
    backgroundColor : "#e4d0ff",
    color :"#120438",
    borderRadius : 6,
    width: '100%',
    borderWidth: 1,
    padding: 16,
  },
  buttonContainer: {
    marginTop: 16,
    flexDirection: 'row',
  },
  button: {
    width: 100,
    marginHorizontal: 8,
  },
  image: {
    width: 100,
    height: 100,
    margin: 20,
  },
});
