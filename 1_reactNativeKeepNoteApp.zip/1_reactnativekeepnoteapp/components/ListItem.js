import React from 'react';
import { Text, View, StyleSheet, Pressable } from 'react-native';

const ListItem = (props) => {
  const onPressDelete = () => {
    props.onPressDeleteHandler(props.item);
  };

  return (
    <View style={styles.goalItem} key={props.index}>
      <Pressable
        android_ripple={{ color: '#dddddd' }}
        onPress={onPressDelete}
        style={({ pressed }) => {
          pressed && styles.pressedItem;
        }}>
        <Text style={styles.goalText}>
          {props.item} {props.index}
        </Text>
      </Pressable>
    </View>
  );
};

export default ListItem;

const styles = StyleSheet.create({
  goalItem: {
    margin: 8,
    borderRadius: 6,
    backgroundColor: '#5e0acc',
    color: 'white',
  },
  pressedItem:{
    opacity:0.1
  },
  goalText: {
    color: 'white',
    padding: 8,
  },
});
